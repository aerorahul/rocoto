# encoding: UTF-8
#
# This include is deprecated, use libxml-ruby instead!

require 'libxml-ruby'