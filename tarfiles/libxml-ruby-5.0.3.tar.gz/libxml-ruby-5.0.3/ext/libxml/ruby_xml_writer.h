#ifndef __RXML_WRITER__
#define __RXML_WRITER__

extern VALUE cXMLWriter;
void rxml_init_writer(void);
#endif
