/* Please see the LICENSE file for copyright and distribution information */

#ifndef __RXML_XPATH_CONTEXT__
#define __RXML_XPATH_CONTEXT__

extern VALUE cXMLXPathContext;
void rxml_init_xpath_context(void);

#endif
