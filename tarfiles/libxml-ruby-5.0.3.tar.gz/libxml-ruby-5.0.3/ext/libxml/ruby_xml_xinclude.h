/* Please see the LICENSE file for copyright and distribution information */

#ifndef __RXML_XINCLUDE__
#define __RXML_XINCLUDE__

extern VALUE cXMLXInclude;
extern VALUE eXMLXIncludeError;

void rxml_init_xinclude(void);

#endif
