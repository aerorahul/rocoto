/* Please see the LICENSE file for copyright and distribution information */

#ifndef __RXML_PARSER__
#define __RXML_PARSER__

extern VALUE cXMLParser;

void rxml_init_parser(void);

#endif
