/* Please see the LICENSE file for copyright and distribution information */

#ifndef __RXML_PARSER_OPTIONS__
#define __RXML_PARSER_OPTIONS__

extern VALUE mXMLParserOptions;

void rxml_init_parser_options(void);

#endif
